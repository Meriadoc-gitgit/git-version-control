#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include "src.h"
#include "bash.h"

int main(void) {

  //À noter avant d'effectuer des tests
  //À insérer une des tests du répertoire main-version
  //Si vous souhaitez de tester la fonction restoreWT, il est recommandé de créer le repertoire de path avant, afin d'éviter les erreurs de segmentation
  //Bon test !

  return 0;
}